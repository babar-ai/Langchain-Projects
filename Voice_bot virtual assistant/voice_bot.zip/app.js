let audioInitialized = false;
let audioPlaying = false;
let mediaRecorder = null;
let socket = null;
let pythonSocket = null;

function startProcess() {
    // Hide the start button and show the end button
    document.getElementById('startButton').style.display = 'none';
    document.getElementById('endButton').style.display = 'block';

    navigator.mediaDevices.getUserMedia({ audio: true }).then((stream) => {
        mediaRecorder = new MediaRecorder(stream, { mimeType: 'audio/webm' });

        // WebSocket URL with endpointing and punctuate parameters
        socket = new WebSocket('wss://api.deepgram.com/v1/listen?language=en&model=nova-2&endpointing=300', 
                               ['token', '26531d68937ef87ac237ea727130bb88bba32240']);

        let transcriptBuffer = '';

        socket.onopen = () => {
            mediaRecorder.addEventListener('dataavailable', event => {
                if (event.data.size > 0) {
                    socket.send(event.data);
                }
            });

            mediaRecorder.start();

            setInterval(() => {
                mediaRecorder.requestData();
            }, 1000);
        };

        pythonSocket = new WebSocket('ws://localhost:8765');

        pythonSocket.onopen = () => {
            console.log('Connected to Python WebSocket server');
        };

        socket.onmessage = (message) => {
            const received = JSON.parse(message.data);
            const transcript = received.channel.alternatives[0].transcript;

            const isUtteranceEnd = received.is_final && received.speech_final;

            if (transcript) {
                transcriptBuffer += transcript + ' ';
            }

            if (isUtteranceEnd && transcriptBuffer) {
                console.log(transcriptBuffer.trim());
                console.log("End of speech detected using UtteranceEnd.");
                
                // Send the transcript to Python WebSocket server
                pythonSocket.send(transcriptBuffer.trim());

                transcriptBuffer = ''; // Clear buffer after sending
            }
        };

    }).catch((error) => {
        console.error('Error accessing audio media:', error);
    });

    initPlayback();
}

function endProcess() {
    // Show the start button and hide the end button
    document.getElementById('startButton').style.display = 'block';
    document.getElementById('endButton').style.display = 'none';

    if (mediaRecorder) {
        mediaRecorder.stop();
    }

    if (socket) {
        socket.close();
    }

    if (pythonSocket) {
        pythonSocket.close();
    }

    // Reset playback status
    audioInitialized = false;
    audioPlaying = false;
}

function initPlayback() {
    if (!audioInitialized) {
        audioInitialized = true;
        checkAndPlayAudio(); // Start checking and playing audio
    }
}

function checkAndPlayAudio() {
    if (!audioInitialized) {
        return;
    }

    fetch('http://localhost:5000/audio')
        .then(response => {
            if (response.ok) {
                // Generate a unique URL by appending a cache-busting query parameter
                const uniqueUrl = `http://localhost:5000/audio?t=${new Date().getTime()}`;
                
                // Play the audio if it's available and not currently playing
                if (!audioPlaying) {
                    const audio = new Audio(uniqueUrl);
                    audio.play().then(() => {
                        console.log("Playing audio...");
                        audioPlaying = true;

                        // Reset after playback is finished
                        audio.onended = () => {
                            audioPlaying = false;
                            fetch('http://localhost:5000/delete_audio');
                        };
                    }).catch(error => {
                        console.error('Error playing audio:', error);
                    });
                }
            } else {
                console.log("File not found, checking again...");
            }
        })
        .catch(error => {
            console.error('Error fetching the audio file:', error);
        })
        .finally(() => {
            // Continue checking every 1 second
            setTimeout(checkAndPlayAudio, 1000); // Check again after 1 second
        });
}
