import asyncio
import websockets
from bot_config import *

from deepgram import (
    DeepgramClient,
    SpeakOptions,
)

last = "Click on the button provided to buy this product. Thanks"

chat_with_history = ChatWithHistory()

def audio_conversion(text):

    SPEAK_OPTIONS = {"text": text}
    filename = "output.wav"

    try:
        # STEP 1: Create a Deepgram client using the API key from environment variables
        deepgram = DeepgramClient(api_key="26531d68937ef87ac237ea727130bb88bba32240")

        # STEP 2: Configure the options (such as model choice, audio configuration, etc.)
        options = SpeakOptions(
            model="aura-orpheus-en",
            encoding="linear16",
            container="wav"
        )

        # STEP 3: Call the save method on the speak property
        response = deepgram.speak.v("1").save(filename, SPEAK_OPTIONS, options)
        print(response.to_json(indent=4))

    except Exception as e:
        print(f"Exception: {e}")


async def handle_transcript(websocket, path):
    async for message in websocket:
        print(f"Received transcript: {message}")
        # Here you can call any Python function or process the transcript further.
        process_transcript(message)


def process_transcript(transcript):
    # Your logic to process the transcript
    print(f"Processing transcript: {transcript}")
    response = chat_with_history.chat(transcript)

    # print(response.content)
    if response.content == "yes":
        global last
        audio_conversion(last)
    audio_conversion(response.content)

start_server = websockets.serve(handle_transcript, "localhost", 8765)

asyncio.get_event_loop().run_until_complete(start_server)
asyncio.get_event_loop().run_forever()