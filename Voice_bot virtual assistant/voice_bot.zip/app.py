from flask import Flask, send_file
from flask_cors import CORS
import os

app = Flask(__name__)
CORS(app)

@app.route('/audio')
def get_audio():
    return send_file('output.wav', mimetype='audio/wav')

@app.route('/delete_audio')
def delete_audio():
    filename = 'output.wav'
    try:
        os.remove(filename)
        return "File deleted successfully", 200
    except OSError as e:
        return f"Error deleting file: {e}", 500

if __name__ == '__main__':
    app.run(port=5000)