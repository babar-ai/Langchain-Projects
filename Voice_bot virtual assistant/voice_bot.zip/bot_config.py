from langchain_core.prompts import ChatPromptTemplate
from langchain_groq import ChatGroq

class ChatWithHistory:
    def __init__(self):
        self.history = []
        self.chain = self.get_chain()

    def get_chain(self):
        chat = ChatGroq(temperature=0, groq_api_key="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", model_name="llama3-8b-8192")

        with open('system_prompt.txt', 'r') as file:
            system = file.read().strip()
        human = "{text}"
        prompt = ChatPromptTemplate.from_messages([("system", system), ("human", human)])

        chain = prompt | chat
        return chain

    def add_to_history(self, role, text):
        self.history.append((role, text))

    def get_prompt(self):
        # Ensure there's at least one system message to start with
        if not self.history:
            raise ValueError("Conversation history is empty. Ensure that the system message is added first.")

        # Convert history to a format suitable for the prompt
        messages = [("system", self.history[0][1])] if self.history else []
        messages.extend(self.history[1:])   

        # Debugging: Print messages to validate format
        print("Messages for prompt:", messages)

        # Ensure all messages are in the correct format
        formatted_messages = []
        for role, content in messages:
            if role not in ["system", "human", "assistant"]:
                raise ValueError(f"Invalid role: {role}")
            if isinstance(content, str):
                formatted_messages.append((role, content))
            elif hasattr(content, 'content'):
                # Extract content from AIMessage or similar
                formatted_messages.append((role, content.content))
            else:
                raise ValueError(f"Invalid content type: {type(content)}")

        return ChatPromptTemplate.from_messages(formatted_messages)

    def chat(self, user_input):
        self.add_to_history("human", user_input)
        prompt = self.get_prompt()
        chain = prompt | self.chain
        response = chain.invoke({"text": user_input})
        self.add_to_history("assistant", response)
        return response



